package com.drawstock.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.ByteBuffer;

public class OverlayService extends Service {
    static final String ACTION_STOP = "com.drawstock.overlay.STOP";
    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";

    private WindowManager wm;
    private Handler main;
    private HandlerThread bgThread;
    private Handler bg;

    private DrawView drawView;
    private WindowManager.LayoutParams drawLp;
    private LinearLayout toolbar;
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelShown = false;
    private FabView fabCollapse, fabPalette, fabPen, fabUndo, fabTrash, fabChart, fabLayers, fabEye, fabExit;
    private boolean drawOn = false, eraserOn = false, collapsed = false, hidden = false, capturing = false;
    private int shapeIdx = 0;
    private final String[] shapeNames = {"自由画笔", "直线", "矩形", "椭圆", "箭头"};

    private MediaProjection mp;
    private VirtualDisplay vd;
    private ImageReader reader;
    private final Object imgLock = new Object();
    private Image latestImage;
    private long latestTime = 0;
    private long hideTime = 0;
    private int captureTries = 0;
    private int capW, capH, capDpi;
    private boolean started = false;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        main = new Handler(Looper.getMainLooper());
        bgThread = new HandlerThread("capture");
        bgThread.start();
        bg = new Handler(bgThread.getLooper());
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int winType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat();
        if (!started) {
            started = true;
            int code = intent.getIntExtra(EXTRA_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_DATA);
            try {
                setupProjection(code, data);
            } catch (Exception e) {
                toast("截屏初始化失败：" + e.getMessage());
            }
            buildOverlay();
        }
        return START_NOT_STICKY;
    }

    private void startForegroundCompat() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("overlay", "悬浮画笔", NotificationManager.IMPORTANCE_LOW));
        }
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent sp = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "overlay") : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_edit)
                .setContentTitle("悬浮画笔运行中")
                .setContentText("点击此通知可停止")
                .setContentIntent(sp);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, n);
        }
    }

    // ---------------------------------------------------------------- 截屏

    private DisplayMetrics realMetrics() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return dm;
    }

    /** 让画布窗口始终等于整个屏幕（含刘海/导航栏区域），这样“截图像素 = 画布像素 + 窗口位置”。 */
    private void fitDrawWindow() {
        if (drawView == null || drawLp == null) return;
        try {
            DisplayMetrics dm = realMetrics();
            if (drawLp.width == dm.widthPixels && drawLp.height == dm.heightPixels && drawLp.x == 0 && drawLp.y == 0) {
                return;
            }
            drawLp.width = dm.widthPixels;
            drawLp.height = dm.heightPixels;
            drawLp.x = 0;
            drawLp.y = 0;
            wm.updateViewLayout(drawView, drawLp);
        } catch (Exception ignored) {
        }
    }

    private ImageReader newReader() {
        ImageReader r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3);
        r.setOnImageAvailableListener(rd -> {
            Image img = null;
            try {
                img = rd.acquireLatestImage();
            } catch (Exception ignored) {
            }
            if (img == null) return;
            synchronized (imgLock) {
                if (latestImage != null) latestImage.close();
                latestImage = img;
                latestTime = SystemClock.uptimeMillis();
            }
        }, bg);
        return r;
    }

    private void setupProjection(int code, Intent data) {
        MediaProjectionManager pm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        mp = pm.getMediaProjection(code, data);
        mp.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                main.post(() -> {
                    toast("屏幕录制已被系统停止，悬浮画笔退出");
                    stopSelf();
                });
            }
        }, main);
        DisplayMetrics dm = realMetrics();
        capW = dm.widthPixels;
        capH = dm.heightPixels;
        capDpi = dm.densityDpi;
        reader = newReader();
        vd = mp.createVirtualDisplay("cap", capW, capH, capDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, bg);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        main.postDelayed(() -> {
            fitDrawWindow();
            if (vd == null || reader == null) return;
            DisplayMetrics dm = realMetrics();
            if (dm.widthPixels == capW && dm.heightPixels == capH) return;
            capW = dm.widthPixels;
            capH = dm.heightPixels;
            capDpi = dm.densityDpi;
            ImageReader old = reader;
            synchronized (imgLock) {
                if (latestImage != null) {
                    latestImage.close();
                    latestImage = null;
                }
            }
            reader = newReader();
            vd.resize(capW, capH, capDpi);
            vd.setSurface(reader.getSurface());
            old.close();
        }, 400);
    }

    private Bitmap imageToBitmap(Image img) {
        if (img == null) return null;
        Image.Plane plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int pixelStride = plane.getPixelStride();
        int rowStride = plane.getRowStride();
        int rowPadding = rowStride - pixelStride * img.getWidth();
        Bitmap bmp = Bitmap.createBitmap(img.getWidth() + rowPadding / pixelStride, img.getHeight(), Bitmap.Config.ARGB_8888);
        bmp.copyPixelsFromBuffer(buf);
        if (rowPadding > 0) {
            Bitmap c = Bitmap.createBitmap(bmp, 0, 0, img.getWidth(), img.getHeight());
            bmp.recycle();
            return c;
        }
        return bmp;
    }

    /** 点击“自动描曲线”：先隐藏自己的所有悬浮窗，再截屏识别，最后画出曲线。无论成功失败都会恢复显示。 */
    private void onChartClick() {
        if (mp == null || reader == null) {
            toast("没有截屏权限，请回到主界面重新启动");
            return;
        }
        if (capturing) return;
        capturing = true;
        hidePanel();
        hideTime = SystemClock.uptimeMillis();
        drawView.setVisibility(View.INVISIBLE);
        toolbar.setVisibility(View.INVISIBLE);
        captureTries = 0;
        main.postDelayed(captureRunnable, 350);
        main.postDelayed(watchdog, 8000);
    }

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (capturing) {
                restoreViews();
                toast("截屏超时，已恢复界面");
            }
        }
    };

    private void restoreViews() {
        capturing = false;
        main.removeCallbacks(watchdog);
        if (drawView != null) drawView.setVisibility(View.VISIBLE);
        if (toolbar != null) toolbar.setVisibility(View.VISIBLE);
    }

    private final Runnable captureRunnable = new Runnable() {
        @Override
        public void run() {
            boolean fresh;
            synchronized (imgLock) {
                fresh = latestImage != null && latestTime >= hideTime + 150;
            }
            if (!fresh && captureTries < 12) {
                captureTries++;
                main.postDelayed(this, 150);
                return;
            }
            bg.post(() -> {
                ChartExtractor.Result res = null;
                int bw = 0;
                String err = null;
                try {
                    Bitmap bmp;
                    synchronized (imgLock) {
                        bmp = imageToBitmap(latestImage);
                    }
                    if (bmp != null) {
                        bw = bmp.getWidth();
                        res = ChartExtractor.extract(bmp);
                        bmp.recycle();
                    }
                } catch (Throwable t) {
                    err = String.valueOf(t);
                    res = null;
                }
                final ChartExtractor.Result fr = res;
                final int fbw = bw;
                final String ferr = err;
                main.post(() -> finishCapture(fr, fbw, ferr));
            });
        }
    };

    private void finishCapture(ChartExtractor.Result res, int bw, String err) {
        restoreViews();
        if (err != null) {
            toast("识别出错：" + err);
            return;
        }
        if (res == null || res.pts == null || res.pts.length < 4 || bw <= 0) {
            toast("没有识别到主图走势曲线（需要蓝色或深色折线，请确认走势图在屏幕上）");
            return;
        }
        // 确保曲线可见
        if (hidden) {
            hidden = false;
            drawView.setContentHidden(false);
            fabEye.setFlipped(false);
            fabEye.setBg(0xFFF50057);
        }
        int[] loc = new int[2];
        drawView.getLocationOnScreen(loc);
        // 截图是整块屏幕的像素；画布窗口可能比屏幕窄（红米等机型横屏时让出刘海/导航栏），
        // 所以缩放只由“真实屏幕宽 / 截图宽”决定（正常为 1），位置偏移再减去画布窗口在屏幕上的位置。
        DisplayMetrics rdm = realMetrics();
        float scale = rdm.widthPixels > 0 ? (float) rdm.widthPixels / bw : 1f;
        float[] pts = res.pts;
        Path p = new Path();
        for (int i = 0; i + 1 < pts.length; i += 2) {
            float x = pts[i] * scale - loc[0];
            float y = pts[i + 1] * scale - loc[1];
            if (i == 0) p.moveTo(x, y);
            else p.lineTo(x, y);
        }
        drawView.replaceAutoCurve(p, Math.max(1f, res.thickness * scale * 0.25f));
        toast("已描出走势曲线");
    }

    // ---------------------------------------------------------------- 悬浮界面

    private void buildOverlay() {
        drawView = new DrawView(this);
        drawView.setStrokeWidth(5f);
        DisplayMetrics fullDm = realMetrics();
        drawLp = new WindowManager.LayoutParams(
                fullDm.widthPixels, fullDm.heightPixels, winType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        drawLp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 30) {
            drawLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            drawLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(drawView, drawLp);

        toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.VERTICAL);
        toolbar.setPadding(0, 0, 0, 0);

        fabCollapse = addFab(FabView.CHEVRON, 0xFF2196F3);
        fabPalette = addFab(FabView.PALETTE, 0xFFD32F2F);
        fabPen = addFab(FabView.BRUSH, 0xFF4CAF50);
        fabUndo = addFab(FabView.UNDO, 0xFFF50057);
        fabTrash = addFab(FabView.TRASH, 0xFFF50057);
        fabChart = addFab(FabView.CHART, 0xFFFF6D00);
        fabLayers = addFab(FabView.LAYERS, 0xFFF50057);
        fabEye = addFab(FabView.EYE, 0xFFF50057);
        fabExit = addFab(FabView.EXIT, 0xFFF50057);

        fabCollapse.setOnClickListener(v -> {
            collapsed = !collapsed;
            fabCollapse.setFlipped(collapsed);
            if (collapsed) hidePanel();
            for (int i = 1; i < toolbar.getChildCount(); i++) {
                toolbar.getChildAt(i).setVisibility(collapsed ? View.GONE : View.VISIBLE);
            }
        });
        fabPalette.setOnClickListener(v -> {
            if (panelShown) hidePanel();
            else showPanel();
        });
        fabPen.setOnClickListener(v -> setDraw(true, false));
        fabUndo.setOnClickListener(v -> drawView.undo());
        fabUndo.setOnLongClickListener(v -> {
            drawView.redo();
            return true;
        });
        fabTrash.setOnClickListener(v -> drawView.clearAll());
        fabChart.setOnClickListener(v -> onChartClick());
        // 图层按钮：切换“在图层上绘制”与“触摸穿透，操作图层下面的 APP”（笔迹仍然显示）
        fabLayers.setOnClickListener(v -> {
            setDraw(!drawOn, false);
            toast(drawOn ? "可在图层上绘制" : "可操作下层APP（笔迹仍显示）");
        });
        fabEye.setOnClickListener(v -> {
            hidden = !hidden;
            drawView.setContentHidden(hidden);
            fabEye.setFlipped(hidden);
            fabEye.setBg(hidden ? 0xFF4CAF50 : 0xFFF50057);
        });
        fabExit.setOnClickListener(v -> stopSelf());
        fabLayers.setFlipped(true);
        fabLayers.setBg(0xFF4CAF50);

        WindowManager.LayoutParams toolLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, winType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        toolLp.gravity = Gravity.TOP | Gravity.START;
        toolLp.x = 0;
        toolLp.y = dp(31);
        if (Build.VERSION.SDK_INT >= 30) {
            toolLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            toolLp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(toolbar, toolLp);
    }

    private FabView addFab(int type, int color) {
        FabView f = new FabView(this, type, color);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(40), dp(40));
        lp.setMargins(0, dp(2), 0, dp(2));
        toolbar.addView(f, lp);
        return f;
    }

    private void setDraw(boolean on, boolean eraser) {
        drawOn = on;
        eraserOn = eraser;
        drawView.setEraser(eraser);
        if (on) drawLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else drawLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        wm.updateViewLayout(drawView, drawLp);
        fabPen.setActive(on);
        fabLayers.setFlipped(!on);
        fabLayers.setBg(on ? 0xFFF50057 : 0xFF4CAF50);
    }

    private void showPanel() {
        if (panelShown) return;
        if (panel == null) buildPanel();
        wm.addView(panel, panelLp);
        panelShown = true;
    }

    private void hidePanel() {
        if (!panelShown) return;
        try {
            wm.removeView(panel);
        } catch (Exception ignored) {
        }
        panelShown = false;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable bgd = new GradientDrawable();
        bgd.setColor(0xF2FFFFFF);
        bgd.setCornerRadius(dp(12));
        panel.setBackground(bgd);

        final int[] colors = {Color.RED, 0xFFFF9800, 0xFFFFEB3B, 0xFF4CAF50, 0xFF00BCD4,
                0xFF2196F3, 0xFF9C27B0, Color.BLACK, Color.WHITE, 0xFF795548};
        for (int row = 0; row < 2; row++) {
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < 5; i++) {
                final int c = colors[row * 5 + i];
                View sw = new View(this);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(c);
                g.setStroke(dp(1), 0xFF999999);
                sw.setBackground(g);
                sw.setOnClickListener(v -> {
                    drawView.setColor(c);
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
                lp.setMargins(dp(4), dp(4), dp(4), dp(4));
                r.addView(sw, lp);
            }
            panel.addView(r);
        }
        TextView label = new TextView(this);
        label.setText("粗细：5 像素");
        label.setTextColor(Color.DKGRAY);
        label.setPadding(dp(4), dp(8), 0, dp(2));
        label.setTextSize(15);
        panel.addView(label);
        SeekBar sb = new SeekBar(this);
        sb.setMax(23);
        sb.setProgress(4);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean user) {
                drawView.setStrokeWidth(p + 1);
                label.setText("粗细：" + (p + 1) + " 像素");
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {}

            @Override
            public void onStopTrackingTouch(SeekBar s) {}
        });
        panel.addView(sb, new LinearLayout.LayoutParams(dp(210), LinearLayout.LayoutParams.WRAP_CONTENT));

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, winType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(46);
        panelLp.y = dp(100);
    }

    // ---------------------------------------------------------------- 清理

    @Override
    public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        hidePanel();
        try {
            if (toolbar != null) wm.removeView(toolbar);
        } catch (Exception ignored) {
        }
        try {
            if (drawView != null) wm.removeView(drawView);
        } catch (Exception ignored) {
        }
        synchronized (imgLock) {
            if (latestImage != null) {
                latestImage.close();
                latestImage = null;
            }
        }
        if (vd != null) vd.release();
        if (reader != null) reader.close();
        if (mp != null) {
            try {
                mp.stop();
            } catch (Exception ignored) {
            }
        }
        if (bgThread != null) bgThread.quitSafely();
        super.onDestroy();
    }
}
