# 悬浮画笔 + 走势图拓印
Draw On Screen 类 APP，橙色“折线”按钮：截取当前屏幕，只识别并描出主图的走势曲线（优先蓝色折线；没有蓝色时取最靠上的深色折线），下方的 A99 指标、成交量等副图不描。再点一次=清除旧曲线并重描。
编译：GitHub Actions（.github/workflows/build-apk.yml），产物在 Actions → Artifacts → DrawStock-apk。
