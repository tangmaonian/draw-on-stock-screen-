package com.drawstock.overlay;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 从截图中识别“深色折线”（走势曲线）并返回按 x 方向顺序的折线点 [x0,y0,x1,y1,...]（截图像素坐标）。
 * 原理：找出所有深灰/黑色（低饱和、低亮度）像素的连通块，取最宽的那一块（走势线横跨图表），
 * 然后逐列取线的上下边界，按路径顺序连接，保留尖刺与竖线段。
 */
final class ChartExtractor {
    private ChartExtractor() {}

    static final class Result {
        float[] pts;
        float thickness;
    }

    static Result extract(Bitmap bmp) {
        final int w = bmp.getWidth(), h = bmp.getHeight();
        final int n = w * h;
        int[] px = new int[n];
        bmp.getPixels(px, 0, w, 0, 0, w, h);

        // 1 = 深色像素, 2 = 已访问, 3 = 已收集
        byte[] st = new byte[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
            int lum = (r * 30 + g * 59 + b * 11) / 100;
            if (lum < 110 && (mx - mn) <= 45) st[i] = 1;
        }
        px = null;

        int[] queue = new int[n];
        ArrayList<int[]> comps = new ArrayList<>();
        int bestW = 0;
        for (int i = 0; i < n; i++) {
            if (st[i] != 1) continue;
            int head = 0, tail = 0;
            queue[tail++] = i;
            st[i] = 2;
            int minX = w, maxX = 0;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (st[q] == 1) {
                            st[q] = 2;
                            queue[tail++] = q;
                        }
                    }
                }
            }
            int cw = maxX - minX + 1;
            comps.add(new int[]{i, cw});
            if (cw > bestW) bestW = cw;
        }
        if (bestW < 100) return null;

        int minKeep = Math.max(60, bestW * 15 / 100);
        int[] ymin = new int[w], ymax = new int[w];
        for (int x = 0; x < w; x++) {
            ymin[x] = -1;
            ymax[x] = -1;
        }
        for (int[] comp : comps) {
            if (comp[1] < minKeep) continue;
            int head = 0, tail = 0;
            queue[tail++] = comp[0];
            st[comp[0]] = 3;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (ymin[x] < 0 || y < ymin[x]) ymin[x] = y;
                if (y > ymax[x]) ymax[x] = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (st[q] == 2) {
                            st[q] = 3;
                            queue[tail++] = q;
                        }
                    }
                }
            }
        }

        ArrayList<Float> pts = new ArrayList<>();
        float prevY = -1;
        ArrayList<Integer> thick = new ArrayList<>();
        for (int x = 0; x < w; x++) {
            if (ymin[x] < 0) continue;
            float y0 = ymin[x], y1 = ymax[x];
            if (y1 - y0 < 7) {
                float m = (y0 + y1) / 2f;
                pts.add((float) x);
                pts.add(m);
                thick.add((int) (y1 - y0 + 1));
                prevY = m;
            } else {
                float first, second;
                if (prevY < 0 || Math.abs(prevY - y0) <= Math.abs(prevY - y1)) {
                    first = y0;
                    second = y1;
                } else {
                    first = y1;
                    second = y0;
                }
                pts.add((float) x);
                pts.add(first);
                pts.add((float) x);
                pts.add(second);
                prevY = second;
            }
        }
        if (pts.size() < 4) return null;
        float[] out = new float[pts.size()];
        for (int i = 0; i < out.length; i++) out[i] = pts.get(i);
        float t = 3f;
        if (!thick.isEmpty()) {
            Collections.sort(thick);
            t = thick.get(thick.size() / 2);
        }
        Result r = new Result();
        r.pts = out;
        r.thickness = Math.max(2.5f, Math.min(12f, t + 0.5f));
        return r;
    }
}
