# 悬浮画笔 + 走势图拓印
Draw On Screen 类 APP，新增橙色“折线”按钮：截取当前屏幕，识别深色走势曲线并描成笔迹（再点一次=清除旧曲线并重描）。
编译：GitHub Actions（.github/workflows/build-apk.yml），产物在 Actions → Artifacts → DrawStock-apk。
