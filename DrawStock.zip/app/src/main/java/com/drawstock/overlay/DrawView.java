package com.drawstock.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;

/** 全屏绘图层。所有笔迹（手绘、形状、自动走势曲线、橡皮擦）都是同一种 Item，按顺序绘制。 */
public class DrawView extends View {
    public static final int SHAPE_FREE = 0, SHAPE_LINE = 1, SHAPE_RECT = 2, SHAPE_OVAL = 3, SHAPE_ARROW = 4;

    private static class Item {
        Path path;
        Paint paint;
        boolean auto; // 是否为“自动走势曲线”
    }

    private final ArrayList<Item> items = new ArrayList<>();
    private final ArrayList<Item> redoStack = new ArrayList<>();
    private Item current;
    private float startX, startY, lastX, lastY;
    private int color = Color.RED;
    private float strokeWidth = 8f;
    private int shape = SHAPE_FREE;
    private boolean eraser = false;
    private boolean contentHidden = false;
    private final PorterDuffXfermode clearMode = new PorterDuffXfermode(PorterDuff.Mode.CLEAR);

    public DrawView(Context c) {
        super(c);
    }

    public void setColor(int c) { color = c; }
    public int getColor() { return color; }
    public void setStrokeWidth(float w) { strokeWidth = w; }
    public void setShape(int s) { shape = s; }
    public void setEraser(boolean e) { eraser = e; }

    public void setContentHidden(boolean h) {
        contentHidden = h;
        invalidate();
    }

    private Paint makePaint(boolean er) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        if (er) {
            p.setColor(Color.BLACK);
            p.setXfermode(clearMode);
            p.setStrokeWidth(strokeWidth * 2.5f);
        } else {
            p.setColor(color);
            p.setStrokeWidth(strokeWidth);
        }
        return p;
    }

    public void undo() {
        if (!items.isEmpty()) {
            redoStack.add(items.remove(items.size() - 1));
            invalidate();
        }
    }

    public void redo() {
        if (!redoStack.isEmpty()) {
            items.add(redoStack.remove(redoStack.size() - 1));
            invalidate();
        }
    }

    public void clearAll() {
        items.clear();
        redoStack.clear();
        invalidate();
    }

    /** 删除旧的自动走势曲线，加入新的（和手绘笔迹完全同类，可撤销/擦除/清空）。 */
    public void replaceAutoCurve(Path path) {
        Iterator<Item> it = items.iterator();
        while (it.hasNext()) {
            if (it.next().auto) it.remove();
        }
        Item n = new Item();
        n.path = path;
        n.paint = makePaint(false);
        n.auto = true;
        items.add(n);
        redoStack.clear();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (contentHidden) return;
        int sc = canvas.saveLayer(0, 0, getWidth(), getHeight(), null);
        for (Item it : items) canvas.drawPath(it.path, it.paint);
        if (current != null) canvas.drawPath(current.path, current.paint);
        canvas.restoreToCount(sc);
    }

    private void buildShape(Path p, float x, float y) {
        p.reset();
        switch (shape) {
            case SHAPE_LINE:
                p.moveTo(startX, startY);
                p.lineTo(x, y);
                break;
            case SHAPE_RECT:
                p.addRect(new RectF(Math.min(startX, x), Math.min(startY, y), Math.max(startX, x), Math.max(startY, y)), Path.Direction.CW);
                break;
            case SHAPE_OVAL:
                p.addOval(new RectF(Math.min(startX, x), Math.min(startY, y), Math.max(startX, x), Math.max(startY, y)), Path.Direction.CW);
                break;
            case SHAPE_ARROW:
                p.moveTo(startX, startY);
                p.lineTo(x, y);
                double ang = Math.atan2(y - startY, x - startX);
                float len = Math.max(30f, strokeWidth * 4f);
                double a1 = ang + Math.PI * 5 / 6, a2 = ang - Math.PI * 5 / 6;
                p.moveTo(x, y);
                p.lineTo(x + (float) Math.cos(a1) * len, y + (float) Math.sin(a1) * len);
                p.moveTo(x, y);
                p.lineTo(x + (float) Math.cos(a2) * len, y + (float) Math.sin(a2) * len);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        boolean free = eraser || shape == SHAPE_FREE;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                current = new Item();
                current.path = new Path();
                current.paint = makePaint(eraser);
                startX = lastX = x;
                startY = lastY = y;
                current.path.moveTo(x, y);
                if (free) current.path.lineTo(x + 0.01f, y);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (current == null) return true;
                if (free) {
                    float mx = (x + lastX) / 2f, my = (y + lastY) / 2f;
                    current.path.quadTo(lastX, lastY, mx, my);
                    lastX = x;
                    lastY = y;
                } else {
                    buildShape(current.path, x, y);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (current != null) {
                    if (free) current.path.lineTo(x, y);
                    else buildShape(current.path, x, y);
                    items.add(current);
                    redoStack.clear();
                    current = null;
                }
                invalidate();
                return true;
            default:
                return true;
        }
    }
}
