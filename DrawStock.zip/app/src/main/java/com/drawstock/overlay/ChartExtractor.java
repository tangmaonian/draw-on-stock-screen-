package com.drawstock.overlay;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 从截图中识别主图“走势曲线”并返回按 x 方向顺序的单值折线点 [x0,y0,x1,y1,...]（截图像素坐标）。
 * 只提取最宽的一条主价格曲线，排除右下角横屏切换按钮、指标线及杂散 UI 图标，确保输出为单条连续曲线。
 */
final class ChartExtractor {
    private ChartExtractor() {}

    static final class Result {
        float[] pts;
        float thickness;
    }

    static Result extract(Bitmap bmp) {
        Result r = tryExtract(bmp, true);
        if (r == null) r = tryExtract(bmp, false);
        return r;
    }

    private static Result tryExtract(Bitmap bmp, boolean blueMode) {
        final int w = bmp.getWidth(), h = bmp.getHeight();
        final int n = w * h;
        int[] px = new int[n];
        bmp.getPixels(px, 0, w, 0, 0, w, h);

        // 1 = 目标颜色像素, 2 = 已访问, 3 = 主曲线连通块
        byte[] st = new byte[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (blueMode) {
                if (b > 150 && b - r > 90 && b - g > 90) st[i] = 1;
            } else {
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                int lum = (r * 30 + g * 59 + b * 11) / 100;
                // 收紧深色阈值（lum < 95），避开灰色半透明悬浮按钮（lum ≈ 108）
                if (lum < 95 && (mx - mn) <= 45) st[i] = 1;
            }
        }
        px = null;

        int[] queue = new int[n];
        int bestSeed = -1;
        int bestW = 0;
        int bestTopY = Integer.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            if (st[i] != 1) continue;
            int head = 0, tail = 0;
            queue[tail++] = i;
            st[i] = 2;
            int minX = w, maxX = 0, minY = h, maxY = 0;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (st[q] == 1) {
                            st[q] = 2;
                            queue[tail++] = q;
                        }
                    }
                }
            }
            int cw = maxX - minX + 1;
            int ch = maxY - minY + 1;
            int area = cw * ch;
            // 过滤实心色块或矩形图标
            if (tail * 100L > area * 30L) continue;
            // 只选择最宽的一条主曲线（若宽度相近则选位置更靠上的主图）
            if (cw > bestW + 20 || (Math.abs(cw - bestW) <= 20 && cw >= 100 && minY < bestTopY)) {
                bestW = cw;
                bestTopY = minY;
                bestSeed = i;
            }
        }

        if (bestSeed < 0 || bestW < 100) return null;

        // 仅标记这唯一一条主曲线连通块（状态 3），彻底隔离其他独立按钮/图标
        int[] ymin = new int[w], ymax = new int[w];
        for (int x = 0; x < w; x++) {
            ymin[x] = -1;
            ymax[x] = -1;
        }
        int head = 0, tail = 0;
        queue[tail++] = bestSeed;
        st[bestSeed] = 3;
        while (head < tail) {
            int p = queue[head++];
            int x = p % w, y = p / w;
            if (ymin[x] < 0 || y < ymin[x]) ymin[x] = y;
            if (y > ymax[x]) ymax[x] = y;
            for (int dy = -1; dy <= 1; dy++) {
                int ny = y + dy;
                if (ny < 0 || ny >= h) continue;
                for (int dx = -1; dx <= 1; dx++) {
                    int nx = x + dx;
                    if (nx < 0 || nx >= w) continue;
                    int q = ny * w + nx;
                    if (st[q] == 2) {
                        st[q] = 3;
                        queue[tail++] = q;
                    }
                }
            }
        }

        // 逐列提取单值曲线点，保证每个 x 最多对应一个 y，绝不产生来回竖线
        ArrayList<Float> pts = new ArrayList<>();
        ArrayList<Integer> thick = new ArrayList<>();
        float prevY = -1f;
        int prevX = -1;

        for (int x = 0; x < w; x++) {
            if (ymin[x] < 0) continue;

            // 若右下角局部（后 15% 宽度）有残余按钮像素粘连，限制单列最大合理高度并贴近前序走势
            int colYMin = ymin[x];
            int colYMax = ymax[x];
            if (prevY >= 0 && (colYMax - colYMin) > h / 12) {
                // 在该列状态为 3 的像素中，寻找离 prevY 最近的连续段
                int bestSegMid = -1;
                int bestDist = Integer.MAX_VALUE;
                int y = colYMin;
                while (y <= colYMax) {
                    if (st[y * w + x] == 3) {
                        int segStart = y;
                        while (y <= colYMax && st[y * w + x] == 3) y++;
                        int segEnd = y - 1;
                        int mid = (segStart + segEnd) / 2;
                        int dist = Math.abs(mid - Math.round(prevY));
                        if (dist < bestDist) {
                            bestDist = dist;
                            bestSegMid = mid;
                        }
                    } else {
                        y++;
                    }
                }
                if (bestSegMid >= 0) {
                    colYMin = bestSegMid;
                    colYMax = bestSegMid;
                }
            }

            float cy = (colYMin + colYMax) / 2f;
            // 若在最右侧边缘出现突发断崖式跳变（通常是右侧边缘图标粘连），直接终止延伸
            if (prevX >= 0 && x > w * 82 / 100 && Math.abs(cy - prevY) > h / 10f && (x - prevX) <= 3) {
                break;
            }

            pts.add((float) x);
            pts.add(cy);
            thick.add(colYMax - colYMin + 1);
            prevY = cy;
            prevX = x;
        }

        if (pts.size() < 4) return null;
        float[] out = new float[pts.size()];
        for (int i = 0; i < out.length; i++) out[i] = pts.get(i);

        float t = 3f;
        if (!thick.isEmpty()) {
            Collections.sort(thick);
            t = thick.get(thick.size() / 2);
        }
        Result r = new Result();
        r.pts = out;
        r.thickness = Math.max(2.5f, Math.min(10f, t + 0.5f));
        return r;
    }
}
