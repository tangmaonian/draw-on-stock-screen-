package com.drawstock.overlay;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 从截图中识别主图“走势曲线”并返回按 x 方向顺序的折线点 [x0,y0,x1,y1,...]（截图像素坐标）。
 * 只描最上面的主价格曲线：优先识别蓝色折线（下方的 A99 指标线、成交量不是蓝色，不会被描）；
 * 若屏幕上没有蓝色曲线，则退回识别深灰/黑色折线，并且只取位置最靠上的那一条。
 * 原理：找出符合颜色的像素连通块，取最宽的那一块（走势线横跨图表），
 * 然后逐列取线的上下边界，按路径顺序连接，保留尖刺与竖线段。
 */
final class ChartExtractor {
    private ChartExtractor() {}

    static final class Result {
        float[] pts;
        float thickness;
    }

    static Result extract(Bitmap bmp) {
        // 先找蓝色主曲线；蓝色里没有横跨的曲线（只有零星蓝字）就退回深色曲线
        Result r = tryExtract(bmp, true);
        if (r == null) r = tryExtract(bmp, false);
        return r;
    }

    private static Result tryExtract(Bitmap bmp, boolean blueMode) {
        final int w = bmp.getWidth(), h = bmp.getHeight();
        final int n = w * h;
        int[] px = new int[n];
        bmp.getPixels(px, 0, w, 0, 0, w, h);

        // 1 = 目标颜色像素, 2 = 已访问, 3 = 已收集
        byte[] st = new byte[n];
        for (int i = 0; i < n; i++) {
            int c = px[i];
            int r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
            if (blueMode) {
                if (b > 150 && b - r > 90 && b - g > 90) st[i] = 1;
            } else {
                int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
                int lum = (r * 30 + g * 59 + b * 11) / 100;
                if (lum < 110 && (mx - mn) <= 45) st[i] = 1;
            }
        }
        px = null;
        // 去掉实心大色块（如右下角“旋转屏幕”小图标压在曲线上时，会把曲线连成一整块）
        removeSolidBlobs(st, w, h);

        int[] queue = new int[n];
        ArrayList<int[]> comps = new ArrayList<>();
        int bestW = 0;
        for (int i = 0; i < n; i++) {
            if (st[i] != 1) continue;
            int head = 0, tail = 0;
            queue[tail++] = i;
            st[i] = 2;
            int minX = w, maxX = 0, minY = h, maxY = 0;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (st[q] == 1) {
                            st[q] = 2;
                            queue[tail++] = q;
                        }
                    }
                }
            }
            int cw = maxX - minX + 1;
            // 实心色块（如悬浮按钮、图标、文字块）不是曲线：曲线占据外框的比例很小
            int area = cw * (maxY - minY + 1);
            if (tail * 100L > area * 30L) continue;
            comps.add(new int[]{i, cw, minY});
            if (cw > bestW) bestW = cw;
        }
        if (bestW < 100) return null;

        int minKeep = Math.max(60, bestW * 15 / 100);
        if (!blueMode) {
            // 深色退回模式：只保留“最靠上”的那条宽曲线（主图），丢弃下方指标线
            int topY = Integer.MAX_VALUE;
            for (int[] comp : comps) {
                if (comp[1] >= minKeep && comp[2] < topY) topY = comp[2];
            }
            ArrayList<int[]> kept = new ArrayList<>();
            for (int[] comp : comps) {
                if (comp[1] >= minKeep && comp[2] <= topY + h / 20) kept.add(comp);
            }
            comps = kept;
            minKeep = 0;
        }
        int[] ymin = new int[w], ymax = new int[w];
        for (int x = 0; x < w; x++) {
            ymin[x] = -1;
            ymax[x] = -1;
        }
        for (int[] comp : comps) {
            if (comp[1] < minKeep) continue;
            int head = 0, tail = 0;
            queue[tail++] = comp[0];
            st[comp[0]] = 3;
            while (head < tail) {
                int p = queue[head++];
                int x = p % w, y = p / w;
                if (ymin[x] < 0 || y < ymin[x]) ymin[x] = y;
                if (y > ymax[x]) ymax[x] = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int q = ny * w + nx;
                        if (st[q] == 2) {
                            st[q] = 3;
                            queue[tail++] = q;
                        }
                    }
                }
            }
        }

        ArrayList<Float> pts = new ArrayList<>();
        float prevY = -1;
        ArrayList<Integer> thick = new ArrayList<>();
        for (int x = 0; x < w; x++) {
            if (ymin[x] < 0) continue;
            float y0 = ymin[x], y1 = ymax[x];
            if (y1 - y0 < 7) {
                float m = (y0 + y1) / 2f;
                pts.add((float) x);
                pts.add(m);
                thick.add((int) (y1 - y0 + 1));
                prevY = m;
            } else {
                float first, second;
                if (prevY < 0 || Math.abs(prevY - y0) <= Math.abs(prevY - y1)) {
                    first = y0;
                    second = y1;
                } else {
                    first = y1;
                    second = y0;
                }
                pts.add((float) x);
                pts.add(first);
                pts.add((float) x);
                pts.add(second);
                prevY = second;
            }
        }
        if (pts.size() < 4) return null;
        float[] out = new float[pts.size()];
        for (int i = 0; i < out.length; i++) out[i] = pts.get(i);
        float t = 3f;
        if (!thick.isEmpty()) {
            Collections.sort(thick);
            t = thick.get(thick.size() / 2);
        }
        Result r = new Result();
        r.pts = out;
        r.thickness = Math.max(2.5f, Math.min(12f, t + 0.5f));
        return r;
    }

    /**
     * 曲线是细线（线宽几个像素），而图标/按钮是实心块：21x21 窗口里 80% 以上都是目标色的地方就是色块，
     * 把色块及其外扩 8 像素的范围清掉，这样色块不会和曲线连在一起。
     */
    private static void removeSolidBlobs(byte[] st, int w, int h) {
        final int r = 10, d = 8;
        if (w < 2 * r + 2 || h < 2 * r + 2) return;
        final int W = w + 1;
        int[] ii = new int[W * (h + 1)];
        for (int y = 0; y < h; y++) {
            int row = 0;
            for (int x = 0; x < w; x++) {
                if (st[y * w + x] == 1) row++;
                ii[(y + 1) * W + x + 1] = ii[y * W + x + 1] + row;
            }
        }
        byte[] solid = new byte[w * h];
        boolean any = false;
        final int full = (2 * r + 1) * (2 * r + 1) * 80 / 100;
        for (int y = r; y < h - r; y++) {
            for (int x = r; x < w - r; x++) {
                if (st[y * w + x] != 1) continue;
                int sum = ii[(y + r + 1) * W + x + r + 1] - ii[(y - r) * W + x + r + 1]
                        - ii[(y + r + 1) * W + x - r] + ii[(y - r) * W + x - r];
                if (sum >= full) {
                    solid[y * w + x] = 1;
                    any = true;
                }
            }
        }
        if (!any) return;
        // 只保留“大块”（外框宽、高都 >= 40 像素）：尖峰处挤在一起的线条簇不够大，不会被误清
        int[] q = new int[w * h];
        boolean big = false;
        for (int s0 = 0; s0 < w * h; s0++) {
            if (solid[s0] != 1) continue;
            int head = 0, tail = 0;
            q[tail++] = s0;
            solid[s0] = 2;
            int bx0 = w, bx1 = 0, by0 = h, by1 = 0;
            while (head < tail) {
                int p = q[head++];
                int x = p % w, y = p / w;
                if (x < bx0) bx0 = x;
                if (x > bx1) bx1 = x;
                if (y < by0) by0 = y;
                if (y > by1) by1 = y;
                for (int dy = -1; dy <= 1; dy++) {
                    int ny = y + dy;
                    if (ny < 0 || ny >= h) continue;
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx;
                        if (nx < 0 || nx >= w) continue;
                        int pp = ny * w + nx;
                        if (solid[pp] == 1) {
                            solid[pp] = 2;
                            q[tail++] = pp;
                        }
                    }
                }
            }
            if (bx1 - bx0 + 1 >= 40 && by1 - by0 + 1 >= 40) {
                big = true;
                for (int k = 0; k < tail; k++) solid[q[k]] = 3;
            }
        }
        q = null;
        if (!big) return;
        for (int y = 0; y < h; y++) {
            int row = 0;
            for (int x = 0; x < w; x++) {
                if (solid[y * w + x] == 3) row++;
                ii[(y + 1) * W + x + 1] = ii[y * W + x + 1] + row;
            }
        }
        for (int y = 0; y < h; y++) {
            int y0 = Math.max(0, y - d), y1 = Math.min(h - 1, y + d);
            for (int x = 0; x < w; x++) {
                if (st[y * w + x] != 1) continue;
                int x0 = Math.max(0, x - d), x1 = Math.min(w - 1, x + d);
                int sum = ii[(y1 + 1) * W + x1 + 1] - ii[y0 * W + x1 + 1]
                        - ii[(y1 + 1) * W + x0] + ii[y0 * W + x0];
                if (sum > 0) st[y * w + x] = 0;
            }
        }
    }
}
