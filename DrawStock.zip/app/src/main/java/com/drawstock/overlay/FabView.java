package com.drawstock.overlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** 圆形悬浮按钮，图标用 Canvas 直接绘制（24x24 网格）。 */
public class FabView extends View {
    public static final int CHEVRON = 0, PALETTE = 1, BRUSH = 2, SHAPES = 3, ERASER = 4,
            UNDO = 5, TRASH = 6, CHART = 7, EYE = 8, EXIT = 9;

    private final int type;
    private int bg;
    private boolean active = false, flipped = false;
    private final Paint bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hole = new Paint(Paint.ANTI_ALIAS_FLAG);

    public FabView(Context c, int type, int bgColor) {
        super(c);
        this.type = type;
        this.bg = bgColor;
        setClickable(true);
        bgPaint.setStyle(Paint.Style.FILL);
        ring.setStyle(Paint.Style.STROKE);
        ring.setColor(0xFFFFFFFF);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFFFFFFFF);
        hole.setStyle(Paint.Style.FILL);
    }

    public void setBg(int c) { bg = c; invalidate(); }
    public void setActive(boolean a) { active = a; invalidate(); }
    public void setFlipped(boolean f) { flipped = f; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        float s = getWidth();
        bgPaint.setColor(bg);
        hole.setColor(bg);
        canvas.drawCircle(s / 2f, s / 2f, s / 2f - 1f, bgPaint);
        if (active) {
            ring.setStrokeWidth(s / 12f);
            canvas.drawCircle(s / 2f, s / 2f, s / 2f - s / 24f, ring);
        }
        canvas.save();
        float u = s / 24f;
        canvas.scale(u, u);
        Path p = new Path();
        switch (type) {
            case CHEVRON:
                stroke.setStrokeWidth(2.4f);
                p.moveTo(7, flipped ? 10 : 14);
                p.lineTo(12, flipped ? 15 : 9);
                p.lineTo(17, flipped ? 10 : 14);
                canvas.drawPath(p, stroke);
                break;
            case PALETTE:
                canvas.drawCircle(12, 12, 8.5f, fill);
                canvas.drawCircle(8, 10, 1.4f, hole);
                canvas.drawCircle(12, 7.5f, 1.4f, hole);
                canvas.drawCircle(16, 10, 1.4f, hole);
                canvas.drawCircle(8.5f, 15, 1.4f, hole);
                canvas.drawCircle(15, 16, 2.2f, hole);
                break;
            case BRUSH:
                stroke.setStrokeWidth(3.2f);
                canvas.drawLine(9, 15, 18, 6, stroke);
                canvas.drawCircle(7, 17, 2.8f, fill);
                break;
            case SHAPES:
                stroke.setStrokeWidth(1.8f);
                p.moveTo(8, 4.5f);
                p.lineTo(12, 11);
                p.lineTo(4, 11);
                p.close();
                canvas.drawPath(p, stroke);
                canvas.drawRect(13, 13, 20, 20, stroke);
                canvas.drawCircle(8, 16.5f, 3.7f, stroke);
                break;
            case ERASER:
                canvas.save();
                canvas.rotate(-45, 12, 12);
                canvas.drawRoundRect(new RectF(4, 8.5f, 20, 15.5f), 2, 2, fill);
                stroke.setColor(bg);
                stroke.setStrokeWidth(1.4f);
                canvas.drawLine(11, 8.5f, 11, 15.5f, stroke);
                stroke.setColor(0xFFFFFFFF);
                canvas.restore();
                break;
            case UNDO:
                stroke.setStrokeWidth(2.2f);
                canvas.drawArc(new RectF(6, 7, 20, 19), 180, 270, false, stroke);
                canvas.drawLine(6, 13, 6, 8.5f, stroke);
                canvas.drawLine(6, 13, 10.5f, 13, stroke);
                break;
            case TRASH:
                stroke.setStrokeWidth(2f);
                canvas.drawLine(6, 7, 18, 7, stroke);
                stroke.setStrokeWidth(1.8f);
                p.moveTo(10, 7);
                p.lineTo(10, 5);
                p.lineTo(14, 5);
                p.lineTo(14, 7);
                canvas.drawPath(p, stroke);
                Path body = new Path();
                body.moveTo(7.5f, 9);
                body.lineTo(16.5f, 9);
                body.lineTo(15.6f, 19);
                body.lineTo(8.4f, 19);
                body.close();
                canvas.drawPath(body, fill);
                break;
            case CHART:
                stroke.setStrokeWidth(1.4f);
                p.moveTo(4, 4);
                p.lineTo(4, 20);
                p.lineTo(20, 20);
                canvas.drawPath(p, stroke);
                stroke.setStrokeWidth(2.2f);
                Path line = new Path();
                line.moveTo(6.5f, 16.5f);
                line.lineTo(10, 11);
                line.lineTo(13.5f, 14);
                line.lineTo(20, 6.5f);
                canvas.drawPath(line, stroke);
                break;
            case EYE:
                stroke.setStrokeWidth(1.8f);
                canvas.drawOval(new RectF(3, 7.5f, 21, 16.5f), stroke);
                canvas.drawCircle(12, 12, 2.6f, fill);
                if (flipped) {
                    stroke.setStrokeWidth(2.4f);
                    canvas.drawLine(5, 19, 19, 5, stroke);
                }
                break;
            case EXIT:
                stroke.setStrokeWidth(2f);
                p.moveTo(13, 5);
                p.lineTo(6, 5);
                p.lineTo(6, 19);
                p.lineTo(13, 19);
                canvas.drawPath(p, stroke);
                canvas.drawLine(10, 12, 19, 12, stroke);
                canvas.drawLine(15.5f, 8.5f, 19, 12, stroke);
                canvas.drawLine(15.5f, 15.5f, 19, 12, stroke);
                break;
            default:
                break;
        }
        canvas.restore();
    }
}
