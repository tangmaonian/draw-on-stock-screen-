package com.drawstock.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_CAP = 1001;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(40), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("悬浮画笔 · 走势图拓印");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView tips = new TextView(this);
        tips.setTextSize(15);
        tips.setPadding(0, dp(16), 0, dp(16));
        tips.setText("使用方法：\n"
                + "1. 点“启动悬浮画笔”，依次授予“显示在其他应用上层”权限和屏幕录制权限（请选择“整个屏幕”，不要选单个应用）。\n"
                + "2. 切到股票 APP，打开 K 线/走势图页面。\n"
                + "3. 点悬浮工具条橙色“折线”按钮：自动把屏幕中间的深色走势曲线描成笔迹。再点一次：清除旧曲线并重新描最新画面。\n"
                + "4. 描出的曲线与手绘笔迹一样：可撤销（点撤销）、重做（长按撤销）、橡皮擦、清空、隐藏。\n\n"
                + "按钮：蓝色=收起/展开　红色=颜色与粗细　绿笔=画笔开/关（关闭时触摸穿透到下层APP）　形状=切换 自由/直线/矩形/椭圆/箭头　橡皮　撤销　垃圾桶=清空　橙色折线=自动描曲线　眼睛=显示/隐藏笔迹　最下=退出");
        ScrollView sv = new ScrollView(this);
        sv.addView(tips);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        Button start = new Button(this);
        start.setText("启动悬浮画笔");
        start.setOnClickListener(v -> startFlow());
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(52)));

        Button stop = new Button(this);
        stop.setText("停止");
        stop.setOnClickListener(v -> {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "已停止", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(52)));
        setContentView(root);
    }

    private void startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许“显示在其他应用上层”，然后返回再点启动", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAP);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAP) return;
        if (res == RESULT_OK && data != null) {
            stopService(new Intent(this, OverlayService.class));
            Intent s = new Intent(this, OverlayService.class);
            s.putExtra(OverlayService.EXTRA_CODE, res);
            s.putExtra(OverlayService.EXTRA_DATA, data);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s);
            else startService(s);
            Toast.makeText(this, "悬浮画笔已启动", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "需要允许屏幕录制，才能识别走势曲线", Toast.LENGTH_LONG).show();
        }
    }
}
